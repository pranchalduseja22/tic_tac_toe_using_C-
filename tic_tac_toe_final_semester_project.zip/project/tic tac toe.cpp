#include <iostream>
using namespace std;

char positions[3][3]={{'1','2','3'},{'4','5','6'},{'7','8','9'}};
char turn='x';
int row,column;
bool draw=false;

/*function 1 start from here*/void display_table()
{
	system("cls");
	cout<<"\n\n\n\t\t\t\t<<*******************************************>>\n\n";
cout<<"\t\t\t\t\t\t WELCOME TO GAME \n";
cout<<"\t\t\t\t\t\t   TIC TAC TOE\n\n";
cout<<"\t\t\t\t<<*******************************************>>\n\n\n";


cout<<"\tPlayer1[x]\n\n";
cout<<"\tPlayer2[o]\n\n";


//for table
cout<<"\t\t\t\t\t\t  |\t   |\t\t\n";
cout<<"\t\t\t\t\t      "<<positions[0][0]<<  "   |    "<<positions[0][1]<<"   |   "<<positions[0][2]<<"\t\t\n";
cout<<"\t\t\t\t\t\t  |\t   |\t\t\n";
cout<<"\t\t\t\t\t   -------|--------|------\n";
cout<<"\t\t\t\t\t\t  |\t   |\t\t\n";
cout<<"\t\t\t\t\t      "<<positions[1][0]<<  "   |    "<<positions[1][1]<<"   |   "<<positions[1][2]<<"\t\t\n";
cout<<"\t\t\t\t\t\t  |\t   |\t\t\n";
cout<<"\t\t\t\t\t   -------|--------|------\n";
cout<<"\t\t\t\t\t\t  |\t   |\t\t\n";
cout<<"\t\t\t\t\t      "<<positions[2][0]<<  "   |    "<<positions[2][1]<<"   |   "<<positions[2][2]<<"\t\t\n";
cout<<"\t\t\t\t\t\t  |\t   |\t\t\n\n\n";
	
	
}//function 1 end here

//function 2 start from here.
void player_turn()
{
	int choice;
if(turn=='x')		
cout<<"\n\n\t\t\t\t\player 1[x]:";

if(turn=='o')		
cout<<"\n\n\t\t\t\t\player 2[o]:";

cin>>choice;

switch(choice)
{ 
case 1:row =0;column=0;break;
case 2:row =0;column=1;break;
case 3:row =0;column=2;break;
case 4:row =1;column=0;break;
case 5:row =1;column=1;break;
case 6:row =1;column=2;break;
case 7:row =2;column=0;break;
case 8:row =2;column=1;break;
case 9:row =2;column=2;break;
default:
	cout<<"\ninvalid no";
	break;
}
if (turn=='x'&&positions[row][column]!='x' &&positions[row][column]!='o')
{
	positions[row][column]='x';
	turn='o';
}
else if (turn=='o'&&positions[row][column]!='x'&&positions[row][column]!='o')
{
	positions[row][column]='o';
	turn='x';
}
else
{
	cout<<"  sorry ! box is already filled \nplease try again!\n\n";
	player_turn();
}
display_table();
}
bool game_over()
{
	//to check which player win
	for(int k=0;k<2;k++)
if(positions[k][0]==positions[k][1] &&positions[k][0]==positions[k][2] || positions[0][k]==positions[1][k] &&positions[0][k]==positions[2][k])
	return false;
if(positions[0][0]==positions[1][1] &&positions[0][0]==positions[2][2] ||positions[2][0]==positions[0][2] )
return false;


	//to check if no one is win
	for(int k=0;k<=2;k++)
	for(int h=0;h<=2;h++)
	if(positions[k][h]!='x'&&positions[k][h]!='o')
	return true;
	
	draw=true;
	return false;
}

int main()
{
int choice;

	
	system("color b");// for change the font colour.



while(game_over())
{display_table();

player_turn();
game_over;

}
if(turn=='o'&&draw==false)
cout<<"\n\n\t\t\t\tcongratulations! player 1 win this game\n\n\n";

else if(turn=='x'&&draw==false)
cout<<"\n\n\t\t\t\tcongratulations! player 2 win this game\n\n\n";
else
cout<<"\n\n\t\t\t\tohh!no one win this game .The game is draw";
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


